WASD:		running
Shift:		walking
LeftClick:	Toggle Direct or Tank controlling (Direct => Character rotates with camera)
AltF4:		Close